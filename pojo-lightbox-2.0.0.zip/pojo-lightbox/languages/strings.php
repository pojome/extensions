<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

__( 'This plugin used to add the lightbox (overlay) effect to all images on your WordPress site with Pojo Framework', 'pojo-lightbox' );