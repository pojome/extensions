<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

__( 'Share content with Facebook, Twitter, and many more on your WordPress site with Pojo Framework.', 'pojo-sharing' );