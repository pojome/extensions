=== Pojo Sharing ===
Contributors: pojo.me, KingYes, ariel.k
Tags: email, print, digg, facebook, google, linkedin, pinterest, Reddit, share, sharing, social, stumbleupon, tumblr, twitter
Requires at least: 3.5
Tested up to: 3.9.2
Stable tag: 2.5.5
License: GPLv2 or later

Share content with Facebook, Twitter, Linkdin, Tumblr and many more networks on your WordPress site with Pojo Framework

== Description ==

**Please Note:** This plugin is only for [Pojo Framework][1] users - Pojo is a premium themes.

This plugin is the exact Sharing module of the original [Jetpack plugin][3], only without all the extra stuff.

**Share with:**
* Twitter
* Facebook
* Tumblr
* Google+
* Pinterest
* Reddit
* LinkedIn
* Email
* Print
* and more

**Contributions:**

Would you like to like to contribute to Pojo Sharing? You are more than welcome to submit your pull requests on the [GitHub repo][2]. Also, if you have any notes about the code, please open a ticket on ths issue tracker.

 [1]: http://pojo.me/?utm_source=wp-repo&utm_medium=link&utm_campaign=sharing
 [2]: https://github.com/pojome/pojo-sharing
 [3]: http://jetpack.me/support/sharing
 

== Installation ==

**Automatic installation**
<ol>
	<li>Install using WordPress' built-in Add New Plugin installer</li>
	<li>Activate the plugin through the 'Plugins' menu in WordPress</li>
	<li>Enjoy!</li>
</ol>

**Manual installation**
<ol>
	<li>Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation</li>
	<li>Activate the plugin through the 'Plugins' menu in WordPress</li>
	<li>Enjoy!</li>
</ol>
<ol>


== Changelog ==

= 2.5.3 =
* Initial Public Release!